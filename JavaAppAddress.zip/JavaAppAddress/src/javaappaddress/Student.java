

package javaappaddress;


public class Student extends User{
    private int year_registracion;
    private int current_semestre;
    private String Course;

    public int getYear_registracion() {
        return year_registracion;
    }

    public void setYear_registracion(int year_registracion) {
        this.year_registracion = year_registracion;
    }

    public int getCurrent_semestre() {
        return current_semestre;
    }

    public void setCurrent_semestre(int current_semestre) {
        this.current_semestre = current_semestre;
    }

    public String getCourse() {
        return Course;
    }

    public void setCourse(String Course) {
        this.Course = Course;
    }
    
}
