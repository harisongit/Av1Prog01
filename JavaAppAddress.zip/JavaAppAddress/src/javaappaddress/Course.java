
package javaappaddress;


public class Course {
    private int codeCurse;
    private String name;
    
    public int getCodeCurse() {
        return codeCurse;
    }

    public void setCodeCurse(int codeCurse) {
        this.codeCurse = codeCurse;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
