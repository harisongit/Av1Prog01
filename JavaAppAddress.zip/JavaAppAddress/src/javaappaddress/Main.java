
package javaappaddress;


public class Main {
    
    public static void main(String[] args) {
    
    //instanciar o objeto Course    
    Course SI = new Course();
    SI.setCodeCurse(20201);
    SI.setName("Sistema de Informaçao");
    
    //instaciar o objeto Estudante
    Student harison = new Student();
    harison.setRegistration(2017);
    harison.setName("HARRISON");
    harison.setLast_name("Almeida");
    harison.setEmail("harison@gmail.com");
    harison.setPassword("12345678");
    harison.setUser_address("Rua Dr Zamenhof nº 511 - Carana");
    harison.setYear_registracion(2017);
    harison.setCurrent_semestre(1);
    harison.setCourse(SI.getName());
    
    //instanciar um objeto Estudante
    
    //Impressao Objeto Course
    System.out.println("Codigo:"+SI.getCodeCurse());
    System.out.println("Curso :"+SI.getName());
    System.out.println("");
    }
}
    
